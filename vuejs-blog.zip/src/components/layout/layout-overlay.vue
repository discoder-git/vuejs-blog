<template lang="html">
    <div class="overlay"></div>
</template>

<style lang="less">
.overlay {
    position: fixed;
    z-index: 998;
    width: 100%;
    height: 100%;
    background: rgba(255,255,255,.8);
}
</style>
