<template lang="html">
    <div class="components-list">
        <div class="content">
            <h1>Страница не найдена.</h1>
        </div>
    </div>
</template>
