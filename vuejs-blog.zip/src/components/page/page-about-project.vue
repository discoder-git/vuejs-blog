<template lang="html">
    <div class="components-list">
        <shared-intro pageName="aboutProject"></shared-intro>
        <div class="content">
            <p><strong><a href="http://linovetskiy.name/">linovetskiy.name</a></strong> - это персональный блог о веб-технологиях с открытым исходным кодом, разработанный как одностраничное приложение на базе <a href="https://vuejs.org/" title="перейти на vuejs.org">Vue.js</a> и <a href="https://vuejs.org/" title="перейти на firebase.google.com">Firebase</a>. Работа над сайтом во многом вдохновлена концепцией <a href="https://www.webcomponents.org/" title="перейти на webcomponents.org">Веб компонентов</a> и современными практиками создания универсальных пользовательских интерфейсов. Это так же является одной из целей проекта - показать пользователям и разработчиками пример построения современного одностраничного приложения.</p><p>Внутри вы найдете статьи и обучающие материалы с примерами кода по широкому кругу веб-технолгий. Подробнее о релизах проекта вы можете почитать в <router-link to="/changelog" href="#">списке изменений</router-link>.</p><p>Больше информации вы можете найти на официальной <a href="https://github.com/discoder-git/vuejs-blog" title="перейти на github.com">странице проекте</a> в GitHub.</p>
        </div>
    </div>
</template>
