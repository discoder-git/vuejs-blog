<template lang="html">
    <div class="components-list">
        <shared-intro pageName="changelog"></shared-intro>
        <div class="content">
            <h2>Релиз бета [<a href="#" title="перейти на github.com">0.2.1</a>] - 00.00.0000</h2>
            <h3>Добавлено:</h3>
            <ol>
                <li><strong>Разделы</strong>
                    <ul>
                        <li><router-link to="/" href="#">Главная</router-link></li>
                        <li><router-link to="/blog" href="#">Блог</router-link></li>
                        <li><router-link to="/about-project" href="#">О проекте</router-link></li>
                        <li><router-link to="/changelog" href="#">Список изменений</router-link></li>
                    </ul>
                </li>
                <li><strong><a href="#" title="перейти на github.com">Компоненты</a></strong>
                    <ul>
                        <li>App</li>
                        <li>page-home</li>
                        <li>page-article-list</li>
                        <li>page-article-item</li>
                        <li>page-about-project</li>
                        <li>page-changelog</li>
                        <li>page-404</li>
                        <li>article-list</li>
                        <li>article-list-concise</li>
                        <li>article-item</li>
                        <li>shared-intro</li>
                        <li>shared-title</li>
                        <li>shared-informer</li>
                        <li>navigation-body</li>
                        <li>navigation-toggle</li>
                        <li>layout-overlay</li>
                    </ul>
                </li>
            </ol>
        </div>
    </div>
</template>
